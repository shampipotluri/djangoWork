from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def home(requests):
    return HttpResponse('This is home page')

def aboutme(requests):
    return HttpResponse('I am Shampi Sri Potluri')

def hobbies(requests):
    return HttpResponse('I love travelling, reading, writing and music')
